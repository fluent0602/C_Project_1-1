#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void swap(int* a, int* b);
void sort(int* a, int* b, int* c);

int main()
{
	int a, b, c;

	printf("���� 3�� �Է� : ");
	scanf("%d %d %d", &a, &b, &c);

	sort(&a, &b, &c);

	printf("���� %d %d %d\n", a, b, c);
}

void swap(int* a, int* b) {
	int temp = *a;
	*a = *b;
	*b = temp;
}

void sort(int* a, int* b, int* c) {
	if (*a < *b) swap(a, b);
	if (*b < *c) swap(b, c);
	if (*a < *b) swap(a, b);
}