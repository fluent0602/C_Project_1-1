#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void riverArr(int* num, int size);

int main()
{
	int num[] = { 1, 3, 5, 7, 9, 11 };
	int size = sizeof(num) / sizeof(num[0]);

	printf("===== ���� �迭 =====\n");
	for (int i = 0; i < size; i++)
	{
		printf("%3d", num[i]);
	}
	printf("\n");

	riverArr(num, size);

	printf("\n");
	printf("===== �Ųٷ� �迭 =====\n");
	for (int i = 0; i < size; i++)
	{
		printf("%3d", num[i]);
	}

	while (1)
	{

	}

	return 0;
}

void riverArr(int* num, int size) {
	int* fptr = &num[0];
	int* bptr = &num[size - 1];
	int bfNum;

	for (int i = 0; i < size / 2; i++)
	{
		bfNum = *(fptr + i);
		*(fptr + i) = *(bptr - i);
		*(bptr - i) = bfNum;
	}
}