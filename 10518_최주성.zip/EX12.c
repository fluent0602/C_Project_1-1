#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void shiftLeft(int* iArr, int size, int count);

int main()
{
	int iArr[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
	int size = sizeof(iArr) / sizeof(iArr[0]);
	int count;

	printf("===== ���� �迭 =====\n");
	for (int i = 0; i < size; i++)
	{
		printf("%3d", iArr[i]);
	}
	printf("\n");

	printf("\nȸ�� Ƚ�� �Է� : ");
	scanf("%d", &count);

	shiftLeft(iArr, size, count);

	printf("\n");
	printf("===== ȸ�� �� �迭 =====\n");
	for (int i = 0; i < size; i++)
	{
		printf("%3d", iArr[i]);
	}

	while (1)
	{

	}
	return 0;
}

void shiftLeft(int* iArr, int size, int count) {
	int num;
	int index;
	for (int i = 0; i < size / 2; i++)
	{
		index = (size + i - count) % size;

		num = iArr[index];
		iArr[index] = iArr[i];
		iArr[i] = num;
	}
}