#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void swap(int* a, int* b);

int main()
{
	int a, b;

	printf("���� 2�� �Է� : ");
	scanf("%d %d", &a, &b);

	printf("��ȯ �� a : %d b : %d\n", a, b);

	swap(&a, &b);

	printf("��ȯ �� a : %d b : %d\n", a, b);
}

void swap(int* a, int* b) {
	int temp = *a;
	*a = *b;
	*b = temp;
}