#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void riverArr(int* num, int size);

int main()
{
	int num[] = { 1, 3, 5, 7, 9, 11 };
	int size = sizeof(num) / sizeof(num[0]);

	printf("===== ���� �迭 =====\n");
	for (int i = 0; i < size; i++)
	{
		printf("%3d", num[i]);
	}
	printf("\n");

	riverArr(num, size);

	printf("\n");
	printf("===== �Ųٷ� �迭 =====\n");
	for (int i = 0; i < size; i++)
	{
		printf("%3d", num[i]);
	}

	return 0;
}

void riverArr(int* num, int size) {
	int bfNum;
	int index;
	for (int i = 0; i < size / 2; i++)
	{
		index = size - i - 1;

		bfNum = num[index];
		num[index] = num[i];
		num[i] = bfNum;
	}
}