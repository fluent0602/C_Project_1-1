#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void searchArr(int* num, int size, int search);

int main()
{
	int num[] = { 3, 4, 5, 9, 10, 12, 13, 15, 20, 22 };
	int search;

	printf("ã�� �� �Է� : ");
	scanf("%d", &search);

	searchArr(num, sizeof(num) / sizeof(num[0]), search);

	return 0;
}

void searchArr(int* num, int size, int search) {
	for (int i = 0; i < size; i++)
	{
		if (search == num[i]) {
			printf("%d�� ã�ҽ��ϴ�", search);
		}
	}
}