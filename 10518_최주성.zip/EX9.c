#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

#define SIZE 5

void arrInput(double* num, int size);
void arrAver(double* num, int size);

int main()
{
	double num[SIZE];

	arrInput(num, SIZE);

	arrAver(num, SIZE);

	return 0;
}

void arrInput(double* num, int size) {
	printf("======�Ǽ� ������ 5�� �Է�======\n");
	for (int i = 0; i < size; i++)
	{
		scanf("%lf", &num[i]);
	}
}

void arrAver(double* num, int size) {
	double sum = 0.0;

	for (int i = 0; i < size; i++)
	{
		sum += num[i];
	}

	double aver = sum / size;
	printf("\n==========��հ� ���==========\n");
	printf("%.2lf", aver);
}